import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-white">
      <h1 className="text-4xl font-semibold text-gray-800">Learn Plus</h1>
    </div>
  );
}
